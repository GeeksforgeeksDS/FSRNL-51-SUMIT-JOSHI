import { Component } from "react";
class Home extends Component{
     courses=["A","B","C","D"];
    render(){
        return(
            <>
               <h3> Home class component</h3>
               <ul>
                  {this.courses.map((val,ind)=> 
                    <li key={ind}> {val} </li>
                )}
               </ul>
            </>
        )
    }
}
export default Home;