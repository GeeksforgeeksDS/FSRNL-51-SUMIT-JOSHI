const About=({myobj,title})=>{
    return(
        <> 
           <h2> {title}</h2>
           <p> {myobj.name} is {myobj.age} year old!</p>
        </>
    )
}
export default About;