const Home=()=>{
    const title="My Home Page";
    let courses=["A","B","C","D","E"];
    return(
        <>
          <h2> {title} </h2>
           {courses.length>0 ? <> 
          <h5> Courses</h5>
          <ul>
              {courses.map((val,ind)=> 
                 <li key={ind}> {val} </li>
              )}
           </ul>
           </> : <p> No Course found</p>}
        </>
    )
}
export default Home;