import Home from './components/Home';
import About from './components/About';
import Counter from './components/Counter';
const App=()=>{
  const obj={name:"sumit",age:23};
  const title="My About Page";
   return(
     <>
        <h1> Welcome to React Js</h1>
        <hr/>
        <Counter />
        <hr/>
        <Home />
        <hr/>
        <About myobj={obj} title={title}/>
     </>
   )
}
export default App;