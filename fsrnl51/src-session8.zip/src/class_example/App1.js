import { Component } from "react";
import Home from "./components/Home";
class App extends Component{
  render(){
    return(
      <>
        <h1> Welcome to Class Component example</h1>
        <p> We learn react js</p>
        <hr/>
        <Home />
      </>
    )
  }
}
export default App;