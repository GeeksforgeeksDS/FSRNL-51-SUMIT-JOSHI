import express from 'express';
const router=express.Router();
 //define routes 
 router.get("/",(req,res)=>{
    res.send("Default route")
 })
  //route parameters 
  router.get('/products/:cname',(req,res)=>{
    let cat=req.params.cname;
    res.send(`${cat} products`)
  }) 
  //optional parameters 
  router.get('/product1/:cname/:scat?',(req,res)=>{
    let cat=req.params.cname;
    let scat=req.params.scat;
    if(scat!=undefined){
    res.send(`${cat} and ${scat} products`)
    }
    else{
        res.send(`${cat} products`)
    }
  }) 

export default router;