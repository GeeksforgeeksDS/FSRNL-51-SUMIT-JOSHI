import express from 'express';
const router=express.Router();
  router.get("/",(req,res)=>{
     res.send("User Home Page")
  })
  router.get("/dashboard",(req,res)=>{
    res.send("User Dashboard Page"+req.title)
 })
 router.post("/adduser",(req,res)=>{
     let newUser=req.body;
     res.send("user data : "+JSON.stringify(newUser))
 })
export default router;