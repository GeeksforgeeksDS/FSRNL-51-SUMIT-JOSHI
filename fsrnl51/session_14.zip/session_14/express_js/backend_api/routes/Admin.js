import express from 'express';
import { checkUser } from '../middleware/routelabel.js';
const router=express.Router();
  router.get("/",checkUser,(req,res)=>{
     res.send("Admin Home Page"+ req.title)
  })
  router.get("/dashboard",(req,res)=>{
    res.send("Admin Dashboard Page")
 })
export default router;