import express from 'express';//import express 
//import routes files 
import MAIN from "./routes/MainRoutes.js";
import USER from "./routes/User.js";
import ADMIN from "./routes/Admin.js";
import { xyz } from './middleware/gloabl.js';
const PORT=7788;//define port 
const app=express();//create instance of the express 
  //global middleware 
  app.use(express.json());//parse post data
 app.use(xyz)
//use routes with the help of middleware
 app.use("/",MAIN);
 app.use('/admin',ADMIN);
 app.use("/user",USER);
 //404 | not found 
  app.use((req,res)=>{
    res.send("No match route found!");
  })
app.listen(PORT,(err)=>{
    if(err) throw err;
    else console.log(`Server work on ${PORT}`);
})