const checkUser=(req,res,next)=>{
      const header=req.headers['name'];
      if(header!=undefined){
         if(header=="geek"){
            next();
         }
         else{
            res.send("Not authorize user")
         }
      }
      else{
        res.send("Please send header")
      }
}
export {checkUser};