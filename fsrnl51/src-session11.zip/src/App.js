import React from 'react';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import NavBar from './components/NavBar';
import Home from './components/Home';
import About from './components/About';
import Service from './components/Service';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Notfound from './components/Notfound';
import Noida from './components/child/Noida'
import Delhi from './components/child/Delhi'
import Gurugram from './components/child/Gurugram'
import Category from './components/Category';
import Products from './components/Products';
const App = () => {
  return (
    <main>
      <Router>
        <NavBar />
        <section className='container'>
            <Routes>
                <Route path='' element={<Home />}/>
                <Route path='about' element={<About />}/>
                <Route path='services' element={<Service />}/>
                <Route path='gallery' element={<Gallery />}/>
                <Route path='products' element={<Products />}/>
                <Route path='category/:cname' element={<Category />}/>
                <Route path='contact' element={<Contact />}>
                    <Route path='noida' element={<Noida />}/>
                    <Route path='delhi' element={<Delhi />}/>
                    <Route path='gurugram' element={<Gurugram />}/>
                </Route>
                <Route path='*' element={<Notfound />}/>
            </Routes>
        </section>
      </Router>
    </main>
  )
}

export default App