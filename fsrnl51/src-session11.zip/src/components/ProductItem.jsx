import React from 'react'
const ProductItem = ({prodItem,addCart}) => {
  return (
    <div className='col-sm-4'>
         <img src={prodItem.image} width={200} height={150} />
         <p>
            <h4> {prodItem.name}</h4>
            Price : Rs.{prodItem.price}
         </p>
         <input type='button' className='btn btn-primary' value="Add cart" onClick={()=> addCart(prodItem.id)}/>
    </div>
  )
}

export default ProductItem