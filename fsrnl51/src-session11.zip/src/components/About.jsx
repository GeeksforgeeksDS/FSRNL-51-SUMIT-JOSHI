import React from 'react'
import ClassCounter from './ClassCounter'

const About = () => {
  return (
    <div>
        <h2> About Us</h2>
        <ClassCounter />
    </div>
  )
}

export default About