import React from 'react'

const Service = () => {
  return (
    <div>Service</div>
  )
}

export default Service