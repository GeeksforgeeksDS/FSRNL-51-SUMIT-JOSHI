import React, { useEffect, useState } from 'react';
import ProductItem from './ProductItem';
import { useSearchParams } from 'react-router-dom';
const pro=[
    {id:1,name:"A",price:5678,image:"https://picsum.photos/200/300"},
    {id:2,name:"B",price:6678,image:"https://picsum.photos/200/300"},
    {id:3,name:"C",price:7678,image:"https://picsum.photos/200/300"},
    {id:4,name:"D",price:8678,image:"https://picsum.photos/200/300"},
    {id:5,name:"E",price:9678,image:"https://picsum.photos/200/300"}
]
const Products = () => {
    const [searchParams,setSearchParams]=useSearchParams();
    const [proData,setProData]=useState(pro);
    useEffect(()=>{
        let ser=searchParams.get('ser');
        console.log(ser)
        if(ser!=null){
        let data=proData.filter(pro=> pro.name==ser);
        setProData(data);
        }
    },[searchParams.get('ser')]);
    const addCart=(id)=>{
        if(localStorage.getItem('mycart')!=undefined){
            let arr=JSON.parse(localStorage.getItem('mycart'));
            if(arr.includes(id)){
                alert("Product already in a cart")
            }
            else{
                arr.push(id);
                localStorage.setItem('mycart',JSON.stringify(arr));
                alert("Product Added to Cart");
                window.location.reload();
            }
        }
        else{
            let arr=[];
            arr.push(id);
            localStorage.setItem('mycart',JSON.stringify(arr));
            alert("Product Added to Cart");
            window.location.reload();
        }
    }
  return (
    <div>
          <h2> Latest Products</h2>
          <div className='row'>
          {
            proData.map(prod=>
                <ProductItem key={prod.id} prodItem={prod} addCart={addCart}/>
            )
          }
          </div>
    </div>
  )
}

export default Products