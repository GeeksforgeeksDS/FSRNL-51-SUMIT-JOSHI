import React from 'react'
import { useSearchParams } from 'react-router-dom'
const Gallery = () => {
  const [searchParams,setSearchParams]=useSearchParams();
  return (
    <div>
      <h2> Gallery</h2>
      <p> Search : {searchParams.get('ser')}</p>
    </div>
  )
}

export default Gallery