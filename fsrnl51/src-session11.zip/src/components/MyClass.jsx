import React, { Component } from 'react'

 class MyClass extends Component {
  render() {
    return (
      <div>
        <h3> {this.props.title}</h3>
      </div>
    )
  }
}

export default MyClass