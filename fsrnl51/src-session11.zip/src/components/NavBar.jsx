import React,{useEffect, useState} from 'react'
import { Link, useNavigate } from 'react-router-dom'
const NavBar = () => {
  const category=["mens","womens","kids"];
  const [cartCount,setCartCount]=useState(0);
  const [search,setSearch]=useState('');
  const navigate=useNavigate();//redirect
  const sendData=(event)=>{
    event.preventDefault();//stop form submision
      if(search!=''){
         navigate(`/products?ser=${search}`)
      }
      else{
        alert("Please fill blank value");
      }
  }
  useEffect(()=>{
     if(localStorage.getItem('mycart')!=undefined){
      let arr=JSON.parse(localStorage.getItem('mycart'));
      setCartCount(arr.length);
     }
  },[])
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
  <div className="container-fluid">
    <Link className="navbar-brand" to="/">Geeks</Link> 
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNav">
      <ul className="navbar-nav">
        <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/">Home</Link> 
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/about">About Us</Link> 
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/services">Cart {cartCount>0 && <span> ({cartCount})</span>}</Link> 
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/products">Products</Link> 
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/gallery">Gallery</Link> 
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/contact">Contact Us</Link> 
        </li>
        <li className="nav-item dropdown">
          <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Category
          </a>
          <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
             {category.map((cat,ind)=> 
                <li key={ind}><Link className="dropdown-item" to={`/category/${cat}`}> {cat} </Link></li>
            )}
          </ul>
        </li>
      </ul>
      <form className="d-flex" onSubmit={sendData}>
        <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" onChange={(event)=> setSearch(event.target.value)}/>
        <button className="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
  )
}

export default NavBar