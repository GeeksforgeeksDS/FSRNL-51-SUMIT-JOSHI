import React from 'react'
import { Link, Outlet } from 'react-router-dom'
const Contact = () => {
  return (
    <div>
        <h2> Contact Us</h2>
        <table className='table'>
           <tr>
               <td width={200}>
                         <ul>
                            <li> <Link to="noida"> Noida</Link></li>
                            <li> <Link to="delhi"> Delhi</Link></li>
                            <li> <Link to="gurugram"> Gurugram</Link></li>
                         </ul>
               </td>
               <td>
                {/*  to load child components  */}
                    <Outlet />
               </td>
           </tr>
        </table>
    </div>
  )
}

export default Contact