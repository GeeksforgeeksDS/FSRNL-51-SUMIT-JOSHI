import React from 'react'

const Delhi = () => {
  return (
    <div>Delhi</div>
  )
}

export default Delhi