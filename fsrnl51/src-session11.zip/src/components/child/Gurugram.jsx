import React from 'react'

const Gurugram = () => {
  return (
    <div>Gurugram</div>
  )
}

export default Gurugram