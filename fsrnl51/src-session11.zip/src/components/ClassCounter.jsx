import { Component } from "react";
import MyClass from "./MyClass";
class ClassCounter extends Component{
    title="Myclass Page";
    //define state 
    constructor(props){
        super(props);
        this.state={count:0}
    }
    INC=()=>{
        //update state
        this.setState({count:this.state.count+1});
    }
    render(){
        return(
            <>
               <h2> Class Component Counter Example</h2>
               <p> The counter is {this.state.count}</p>
               <button onClick={this.INC}> ++ </button>
               <hr/>
               <MyClass title={this.title}/>
            </>
        )
    }
}
export default ClassCounter;