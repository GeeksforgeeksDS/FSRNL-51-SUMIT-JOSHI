import React from 'react'

const Notfound = () => {
  return (
    <div>
        <h2> 404 ! Page not found !</h2>
    </div>
  )
}

export default Notfound