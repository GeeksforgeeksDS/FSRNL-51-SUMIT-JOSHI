import React, { useState } from 'react';
import {addProduct} from '../services/ProductService'
import {useNavigate} from 'react-router-dom'
const AddProduct = () => {
  const [state,setState]=useState({name:'',price:'',quantity:''});
  const navigate=useNavigate();
  const handler=(event)=>{
     const {name,value}=event.target;
     setState({...state,[name]:value});
  }
  const handleSubmit=(event)=>{
      event.preventDefault();//stop form submission
      addProduct(state)
      .then(res=>{
         if(res.data){
           alert("Product Added");
           //redirect to product 
           navigate("/products");
         }
      })
      .catch(err=> console.log(err))
  }
  return (
    <div>
        <h2> Add Product</h2>
        <form onSubmit={handleSubmit}>
            <div className="form-group">
               <label> Name </label>
               <input type='text' name='name' className='form-control' onChange={handler}/>
            </div>
            <div className="form-group">
               <label> Price </label>
               <input type='text' name='price' className='form-control' onChange={handler}/>
            </div>
            <div className="form-group">
               <label> Quantity </label>
               <input type='text' name='quantity' className='form-control' onChange={handler}/>
            </div>
            <input type='submit' value="Add" className="btn btn-success"/>
        </form>
    </div>
  )
}

export default AddProduct