import React from 'react'
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Home from './components/Home';
import NavBar from './components/NavBar';
import Products from './components/Products';
import AddProduct from './components/AddProduct';
import EditProduct from './components/EditProduct';
const App = () => {
  return (
    <main>
      <Router>
         <NavBar />
          <section className='container'>
              <Routes>
                  <Route path='' element={<Home />}/>
                  <Route path='products' element={<Products />}/>
                  <Route path='addproduct' element={<AddProduct />}/>
                  <Route path='editproduct/:id' element={ <EditProduct />}/>
              </Routes>
          </section>
      </Router>
    </main>
  )
}

export default App