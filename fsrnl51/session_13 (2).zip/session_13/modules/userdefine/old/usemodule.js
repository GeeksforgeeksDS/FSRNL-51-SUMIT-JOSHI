const {TITLE,data}=require('./mymodule.js');
console.log(TITLE);
console.log(data());