const TITLE="Hello Module";
const obj={
      fname:"anuj",
      lname:"joshi"
}
const data=()=>{
      return "Geeks for Geek"
}
module.exports={TITLE,obj,data};