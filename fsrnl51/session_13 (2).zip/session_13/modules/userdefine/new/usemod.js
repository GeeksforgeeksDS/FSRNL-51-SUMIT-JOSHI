import {obj,API} from './mod.js';
console.log(API);
obj.success("Work Done !")
obj.error("Some error occur !")
obj.warning("Some warning occur !")