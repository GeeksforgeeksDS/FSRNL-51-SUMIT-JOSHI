import fs from 'fs';
// fs.mkdir('./sumit',(err)=>{
//    if(err){
//        console.log("Already exists")
//    }
//    else{
//      console.log("Folder created successfully");
//    }
// }
//let folder=fs.mkdirSync("./sumit");
 let file=fs.existsSync('./sumit/my.txt');
 if(file){
      fs.readFile('./sumit/my.txt',(err,data)=>{
        if(err) throw err;
        else console.log(" Data is "+ data.toString())
      })
 }
 else{
      fs.writeFile('./sumit/my.txt',"hello how r u",(err)=>{
         if(err) throw err;
         else console.log("File created")
      })
 }