console.log("Start");
setTimeout(()=>{
   console.log("Hello")
},2000)
console.log("End");