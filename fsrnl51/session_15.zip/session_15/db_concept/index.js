import express from 'express';
import DBRoute from './routes/DB_Routes.js';
import db_connection from './db.js';
const PORT=8899;
const app=express();
db_connection();
app.use("/database/v1",DBRoute);
//404 not found 
app.use((req,res)=>{
    res.send("No route match")
})
app.listen(PORT,(err)=>{
    if(err) throw err;
    else console.log(`Server work on ${PORT}`)
})