import mongoose from "mongoose";
const db_connection=async ()=>{
   try{
      const connection_string="mongodb://127.0.0.1:27017/geekpractice";
      await mongoose.connect(connection_string);
      console.log("MongoDb Connected");
   }
   catch(err){
      console.log("Some mongo db connection error "+err)
   }
}
export default db_connection;