import express from 'express';
import userModel from '../model/UserSchema.js';
const router = express.Router();
router.get("/create", async (req, res) => {
    try {
        let newUser = {
            name: "sumit",
            email: "sumit@gmail.com",
            password: "asumit123",
            age: 35
        }
        //insert data
        let user = new userModel(newUser);
        await user.save();
        res.send("Data inserted")
    }
    catch (err) {
        res.send("Something went wrong or already exists")
    }
})
router.get("/getdata", async (req, res) => {
    try {
         let userData=await userModel.find();//find
        res.json({"err":0,"data":userData})
    }
    catch (err) {
        res.send("Something went wrong")
    }
})
export default router;