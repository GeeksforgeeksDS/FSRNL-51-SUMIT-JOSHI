import express from "express";
import { PORT } from "./constants.js";
import AuthRoute from "./routes/AuthRoutes.js";
import ProductRoute from "./routes/ProductRoutes.js";
import dbconnection from "./dbconnection.js";
const app=express();
app.use(express.json());//post data parse
dbconnection();
//call routes (define api url)
app.use("/api/v1/auth",AuthRoute);
app.use("/api/v1/product",ProductRoute);
//not found 
app.use((req,res)=>{
    res.status(404).send("No route found")
})
app.listen(PORT,(err)=>{
    if(err) throw err;
    else console.log(`Server work on ${PORT}`)
})