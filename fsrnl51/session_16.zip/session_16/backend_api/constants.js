const PORT=7788;
const CONNECTION_STRING="mongodb://127.0.0.1:27017/geek2project";
export {PORT,CONNECTION_STRING};