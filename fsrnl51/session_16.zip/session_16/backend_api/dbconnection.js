import mongoose from "mongoose";
import { CONNECTION_STRING } from "./constants.js";
const dbconnection=async ()=>{
  try{
      await mongoose.connect(CONNECTION_STRING);
      console.log("MongoDB Connected");
  }
  catch(err){
    console.log("Database connection error : "+err);
  }
}
export default dbconnection;