import ProductModel from "../models/ProductModel.js";
const getProducts=async (req,res)=>{
    try{
       let products=await ProductModel.find();
       res.json({"err":0,"products":products});
    }
    catch(err){
        res.json({"err":1,"msg":"Something went wrong to fetch products"})
    }
   
}
const getProductById=async (req,res)=>{
    try{
      let id=req.params.id;
      let product=await ProductModel.findById(id);
      if(!product){
        res.json({"err":1,"msg":"Something went wrong"})
      }
       res.json({"err":0,"product":product})
    }
    catch(err){
        res.json({"err":1,"msg":"Something went wrong"})
    }
   
}
const addProduct=async (req,res)=>{
   try{
       let newProduct=new ProductModel(req.body);
       await newProduct.save();
       res.json({"err":0,"msg":"Product Added"})
   }
   catch(err){
    res.json({"err":1,"msg":"Already exists or something went wrong"})
   }
}
const deleteProduct=async (req,res)=>{
    try{
       let id=req.params.id;
       const product=await ProductModel.findByIdAndDelete(id);
       if(!product){
        res.json({"err":1,"msg":"Something went wrong to delete product"})
       }
       res.json({"err":0,"msg":"Product Deleted"})
    }
    catch(err){
        res.json({"err":1,"msg":"Something went wrong to delete product"})
    }
}
const updateProduct=(req,res)=>{
    res.json({"err":0,"msg":"Product Updated"})
}
export {getProducts,getProductById,addProduct,deleteProduct,updateProduct}